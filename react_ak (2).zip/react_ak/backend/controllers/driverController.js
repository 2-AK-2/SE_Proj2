// controllers/driverController.js
import bcrypt from "bcryptjs";
import jwt from "jsonwebtoken";
import db from "../config/db.js";
import fs from "fs";
import path from "path";
import dotenv from "dotenv";

dotenv.config();
const JWT_SECRET = process.env.JWT_SECRET || "supersecretkey";

// ========== REGISTER DRIVER ==========
export const registerDriver = async (req, res) => {
  try {
    const { name, email, password } = req.body;

    const licenseFile = req.files?.license?.[0];
    const vehicleDocFile = req.files?.vehicleDoc?.[0];

    if (!name || !email || !password || !licenseFile || !vehicleDocFile)
      return res.status(400).json({ message: "All fields required" });

    const [existing] = await db.execute("SELECT id FROM drivers WHERE email = ?", [
      email,
    ]);

    if (existing.length > 0)
      return res.status(409).json({ message: "Email already exists" });

    const hashed = await bcrypt.hash(password, 10);

    const [result] = await db.execute(
      `INSERT INTO drivers
       (name, email, password, license_doc, vehicle_doc, verified)
       VALUES (?, ?, ?, ?, ?, 1)`,
      [name, email, hashed, licenseFile.path, vehicleDocFile.path]
    );

    res.json({ message: "Driver registered", id: result.insertId });
  } catch (err) {
    console.error("❌ registerDriver:", err);
    res.status(500).json({ message: "Internal error" });
  }
};

// ========== LOGIN DRIVER ==========
export const loginDriver = async (req, res) => {
  try {
    const { email, password } = req.body;

    const [rows] = await db.execute("SELECT * FROM drivers WHERE email = ?", [
      email,
    ]);

    if (!rows.length) return res.status(401).json({ message: "Invalid login" });

    const driver = rows[0];

    const ok = await bcrypt.compare(password, driver.password);
    if (!ok) return res.status(401).json({ message: "Invalid login" });

    const token = jwt.sign({ id: driver.id }, JWT_SECRET, { expiresIn: "24h" });

    res.json({
      token,
      driver: { id: driver.id, name: driver.name, email: driver.email },
    });
  } catch (err) {
    console.error("❌ login error:", err);
    res.status(500).json({ message: "Internal error" });
  }
};

// ========== FETCH DRIVER PROFILE ==========
export const getDriverProfile = async (req, res) => {
  try {
    const [rows] = await db.execute(
      `SELECT id, name, email, phone, profile_picture,
              license_doc, vehicle_doc
       FROM drivers WHERE id = ?`,
      [req.user.id]
    );

    if (!rows.length)
      return res.status(404).json({ message: "Driver not found" });

    res.json(rows[0]);
  } catch (err) {
    console.error("❌ getProfile:", err);
    res.status(500).json({ message: "Internal error" });
  }
};


// ========== UPDATE DRIVER PROFILE ==========
export const updateDriverProfile = async (req, res) => {
  try {
    const id = req.user.id;
    const { name, phone } = req.body;

    const profilePic = req.files?.profile_picture?.[0]?.path || null;
    const licenseDoc = req.files?.license?.[0]?.path || null;
    const vehicleDoc = req.files?.vehicleDoc?.[0]?.path || null;

    await db.execute(
      `
      UPDATE drivers SET
        name = COALESCE(?, name),
        phone = COALESCE(?, phone),
        profile_picture = COALESCE(?, profile_picture),
        license_doc = COALESCE(?, license_doc),
        vehicle_doc = COALESCE(?, vehicle_doc)
      WHERE id = ?
      `,
      [name, phone, profilePic, licenseDoc, vehicleDoc, id]
    );

    res.json({ message: "Profile updated" });
  } catch (err) {
    console.error("❌ updateProfile:", err);
    res.status(500).json({ message: "Internal error" });
  }
};



// ========== CHANGE PASSWORD ==========
export const changeDriverPassword = async (req, res) => {
  try {
    const { oldPassword, newPassword } = req.body;

    const [rows] = await db.execute("SELECT password FROM drivers WHERE id = ?", [
      req.user.id,
    ]);

    if (!rows.length) return res.status(404).json({ message: "Driver not found" });

    const valid = await bcrypt.compare(oldPassword, rows[0].password);
    if (!valid) return res.status(400).json({ message: "Old password wrong" });

    const hashed = await bcrypt.hash(newPassword, 10);

    await db.execute("UPDATE drivers SET password = ? WHERE id = ?", [
      hashed,
      req.user.id,
    ]);

    res.json({ message: "Password updated" });
  } catch (err) {
    console.error("❌ changePass:", err);
    res.status(500).json({ message: "Internal error" });
  }
};

export const rateRider = async (req, res) => {
  try {
    const { riderId, rating } = req.body;

    if (!riderId || !rating) {
      return res.status(400).json({ message: "Missing rating or riderId" });
    }

    await db.execute(
      "INSERT INTO rider_ratings (driver_id, rider_id, rating) VALUES (?, ?, ?)",
      [req.user.id, riderId, rating]
    );

    res.json({ message: "Rating submitted" });
  } catch (err) {
    console.error("❌ rateRider:", err);
    res.status(500).json({ message: "Internal error" });
  }
};
