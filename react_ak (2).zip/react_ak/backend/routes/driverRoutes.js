import express from "express";
import multer from "multer";
import {
  registerDriver,
  loginDriver,
  rateRider,
  getDriverProfile,
  updateDriverProfile,
  changeDriverPassword,
} from "../controllers/driverController.js";
import { verifyToken } from "../middleware/auth.js";

const router = express.Router();

// Multer Storage
const storage = multer.diskStorage({
  destination: function (req, file, cb) {
    const field = file.fieldname;
    let folder = "uploads/vehicles";

    if (field === "license") folder = "uploads/licenses";
    else if (field === "profile_picture") folder = "uploads/profiles";
    else if (field === "vehicleDoc") folder = "uploads/vehicles";

    cb(null, folder);
  },
  filename: function (req, file, cb) {
    cb(null, Date.now() + "-" + file.originalname);
  },
});

const upload = multer({ storage });

// Register
router.post(
  "/register",
  upload.fields([
    { name: "license", maxCount: 1 },
    { name: "vehicleDoc", maxCount: 1 },
  ]),
  registerDriver
);

// Login
router.post("/login", loginDriver);

// Profile
router.get("/profile", verifyToken, getDriverProfile);

// Profile update
router.post(
  "/profile/update",
  verifyToken,
  upload.fields([
    { name: "profile_picture", maxCount: 1 },
    { name: "license", maxCount: 1 },
    { name: "vehicleDoc", maxCount: 1 },
  ]),
  updateDriverProfile
);

// Change password
router.post("/profile/change-password", verifyToken, changeDriverPassword);

// Rate rider
router.post("/rate", verifyToken, rateRider);

export default router;
