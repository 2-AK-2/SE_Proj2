// src/pages/DriverLogin.js
import React, { useState } from "react";
import { driverAPI } from "../api/api";
import { setDriverToken } from "../utils/authHelper";
import { useNavigate } from "react-router-dom";

export default function DriverLogin() {
  const nav = useNavigate();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");

  const handleSubmit = async (e) => {
    e.preventDefault();

    try {
      const res = await driverAPI.login({ email, password });

      setDriverToken(res.token); // ✔ save JWT
      nav("/driver/profile");
    } catch (err) {
      alert("Invalid login");
    }
  };

  return (
    <div className="login-page">
      <h2>Driver Login</h2>

      <form onSubmit={handleSubmit}>
        <input 
          type="email" 
          placeholder="Email"
          value={email}
          onChange={(e)=>setEmail(e.target.value)}
        />

        <input 
          type="password" 
          placeholder="Password"
          value={password}
          onChange={(e)=>setPassword(e.target.value)}
        />

        <button>Login</button>
      </form>
    </div>
  );
}
