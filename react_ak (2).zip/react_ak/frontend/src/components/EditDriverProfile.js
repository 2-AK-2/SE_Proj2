// src/pages/EditDriverProfile.js
import React, { useEffect, useState } from "react";
import { driverAPI } from "../api/api";
import { useNavigate } from "react-router-dom";

export default function EditDriverProfile() {
  const nav = useNavigate();
  const [profile, setProfile] = useState({ name: "", phone: "" });

  useEffect(() => {
    driverAPI.getProfile().then((data) => {
      setProfile({
        name: data.name,
        phone: data.phone || ""
      });
    });
  }, []);

  const handleSave = async () => {
    try {
      await driverAPI.updateProfile(profile);
      alert("Profile updated!");
      nav("/driver/profile");
    } catch (err) {
      alert("Failed to update");
    }
  };

  return (
    <div className="edit-profile">
      <h2>Edit Profile</h2>

      <input
        type="text"
        placeholder="Full Name"
        value={profile.name}
        onChange={(e) => setProfile({ ...profile, name: e.target.value })}
      />

      <input
        type="text"
        placeholder="Phone Number"
        value={profile.phone}
        onChange={(e) => setProfile({ ...profile, phone: e.target.value })}
      />

      <button onClick={handleSave}>Save</button>
    </div>
  );
}
