// src/pages/DriverChangePassword.js
import React, { useState } from "react";
import { driverAPI } from "../api/api";
import { useNavigate } from "react-router-dom";

export default function DriverChangePassword() {
  const nav = useNavigate();

  const [oldPassword, setOld] = useState("");
  const [newPassword, setNew] = useState("");

  const handleChange = async () => {
    try {
      await driverAPI.changePassword({ oldPassword, newPassword });
      alert("Password updated!");
      nav("/driver/profile");
    } catch (err) {
      alert("Error changing password");
    }
  };

  return (
    <div className="change-password">
      <h2>Change Password</h2>

      <input
        type="password"
        placeholder="Old Password"
        value={oldPassword}
        onChange={(e) => setOld(e.target.value)}
      />

      <input
        type="password"
        placeholder="New Password"
        value={newPassword}
        onChange={(e) => setNew(e.target.value)}
      />

      <button onClick={handleChange}>Update Password</button>
    </div>
  );
}
