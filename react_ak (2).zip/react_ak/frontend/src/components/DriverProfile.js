// src/pages/DriverProfile.js
import React, { useEffect, useState } from "react";
import { driverAPI } from "../api/api";
import { useNavigate } from "react-router-dom";

export default function DriverProfile() {
  const nav = useNavigate();
  const [profile, setProfile] = useState(null);

  const loadProfile = async () => {
    try {
      const p = await driverAPI.getProfile();
      setProfile(p);
    } catch (err) {
      alert("Failed to load profile");
    }
  };

  useEffect(() => {
    loadProfile();
  }, []);

  if (!profile) return <h3>Loading...</h3>;

  return (
    <div className="profile-page">
      <h2>Driver Profile</h2>

      <p><b>Name:</b> {profile.name}</p>
      <p><b>Email:</b> {profile.email}</p>
      <p><b>Phone:</b> {profile.phone || "Not set"}</p>

      <button onClick={() => nav("/driver/profile/edit")}>
        Edit Profile
      </button>

      <button onClick={() => nav("/driver/profile/change-password")}>
        Change Password
      </button>
    </div>
  );
}
